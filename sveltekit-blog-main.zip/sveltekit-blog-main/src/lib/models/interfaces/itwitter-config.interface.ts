export interface ITwitterConfig {
	TWITTER_API_KEY: string;
	TWITTER_TWEETS_ENDPOINT: string;
	TWITTER_SEARCH_URL: string;
}
