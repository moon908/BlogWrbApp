import type { APIS_TYPE } from './apis.type';

export type SVELTEKIT_STARTER_APIS_TYPE = 'GITHUB' | APIS_TYPE;
