export interface IVideoSnippet {
	title: string;
	description: string;
}
