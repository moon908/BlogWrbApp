export interface ITopTrack {
	title: string;
	ranking: string;
	songUrl: string;
	artist: string;
}
