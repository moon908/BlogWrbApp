export { default as NowPlaying } from './NowPlaying.svelte';
