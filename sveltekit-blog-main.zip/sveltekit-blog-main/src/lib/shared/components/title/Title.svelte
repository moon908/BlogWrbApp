<script lang="ts">
	export let title = 'Svelte';
</script>

<svelte:head>
	<title>{title}</title>
</svelte:head>
