declare module '@squoosh/lib';
