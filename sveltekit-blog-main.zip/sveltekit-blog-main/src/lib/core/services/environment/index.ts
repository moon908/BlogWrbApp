export { sveltekitStarterEnvironmentFacade } from './environment.facade';
