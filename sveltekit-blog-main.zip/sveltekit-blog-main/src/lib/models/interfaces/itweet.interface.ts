export interface ITweet {
	text: string;
	id: string;
	author: string;
	media: string;
	created_at: string;
	public_metrics: string;
	referenced_tweets: string;
}
