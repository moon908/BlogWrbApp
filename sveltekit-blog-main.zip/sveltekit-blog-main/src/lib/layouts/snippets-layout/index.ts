export { default as SnippetsLayout } from './SnippetsLayout.svelte';
