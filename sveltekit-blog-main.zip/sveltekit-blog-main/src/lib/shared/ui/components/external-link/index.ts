export { default as ExternalLink } from './ExternalLink.svelte';
