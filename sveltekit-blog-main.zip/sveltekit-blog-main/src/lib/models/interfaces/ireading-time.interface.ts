export interface IReadingTime {
	text: string;
}
