// LOCAL
export enum SVELTEKIT_DATA_ENPOINTS_PROD {
	SERVICE = '/service',
}

export enum SVELTEKIT_SEARCH_ENPOINTS_PROD {
	SEARCH = '/search',
}
