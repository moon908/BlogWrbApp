export interface ISessionConfig {
	SESSION_KEY: string;
}
