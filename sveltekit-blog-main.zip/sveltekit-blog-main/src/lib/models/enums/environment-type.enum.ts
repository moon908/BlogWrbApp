export enum EnvironmentType {
	PROD,
	QA,
	DEV,
	LOCAL,
}
