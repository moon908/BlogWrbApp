// LOCAL
export enum SVELTEKIT_DATA_ENPOINTS {
	SERVICE = '/service',
}

export enum SVELTEKIT_SEARCH_ENPOINTS {
	SEARCH = '/search',
}
