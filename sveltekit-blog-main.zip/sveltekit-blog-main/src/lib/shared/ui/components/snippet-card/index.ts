export { default as SnippetCard } from './SnippetCard.svelte';
