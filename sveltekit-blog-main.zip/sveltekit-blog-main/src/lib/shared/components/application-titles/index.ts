export { default as ApplicationTitles } from './ApplicationTitles.svelte';
