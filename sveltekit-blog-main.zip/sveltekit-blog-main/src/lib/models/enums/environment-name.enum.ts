export enum EnvironmentName {
	PRODUCTION = 'Production',
	QA = 'QA',
	DEVELOPMENT = 'Developement',
	LOCAL = 'Local',
}
