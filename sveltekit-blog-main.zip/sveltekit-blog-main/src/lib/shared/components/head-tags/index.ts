export { default as HeadTags } from './HeadTags.svelte';
