export interface IProjectCard {
	title: string;
	description: string;
	slug: string;
	icon: string;
}
