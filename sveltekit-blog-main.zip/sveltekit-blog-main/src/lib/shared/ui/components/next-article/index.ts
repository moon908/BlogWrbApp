export { default as NextArticle } from 'NextArticle.svelte';
