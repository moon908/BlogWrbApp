export { default as ProjectCard } from './ProjectCard.svelte';
