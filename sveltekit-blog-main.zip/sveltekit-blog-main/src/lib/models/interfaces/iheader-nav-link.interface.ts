export interface IHeaderNavLink {
	label: string;
	path: string;
}
