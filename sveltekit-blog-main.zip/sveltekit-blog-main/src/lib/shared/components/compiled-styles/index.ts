export { default as CompiledStyles } from './CompiledStyles.svelte';
