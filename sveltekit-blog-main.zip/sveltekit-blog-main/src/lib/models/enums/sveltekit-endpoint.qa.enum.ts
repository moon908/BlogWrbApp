// LOCAL
export enum SVELTEKIT_DATA_ENPOINTS_QA {
	SERVICE = '/service',
}

export enum SVELTEKIT_SEARCH_ENPOINTS_QA {
	SEARCH = '/search',
}
