export { default as VideoCard } from './VideoCard.svelte';
