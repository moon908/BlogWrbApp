export interface IGitHubConfig {
	GITHUB_BLOG_EDIT_URL: string;
	GITHUB_SNIPPETS_EDIT_URL: string;
	GITHUB_API_URL: string;
	GITHUB_USER_ENDPOINT: string;
	GITHUB_USER_REPO_ENDPOINT: string;
}
