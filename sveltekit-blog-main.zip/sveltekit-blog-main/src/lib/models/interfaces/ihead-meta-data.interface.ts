export interface IHeadMetaData {
	title: string;
	description: string;
}
