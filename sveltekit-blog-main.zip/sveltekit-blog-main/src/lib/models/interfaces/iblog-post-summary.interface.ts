export interface IBlogPostSummary {
	title: string;
	summary: string;
	slug: string;
}
