import type { IConfig } from './iconfig.interface';

export type IEnvironmentConfig = IConfig;
