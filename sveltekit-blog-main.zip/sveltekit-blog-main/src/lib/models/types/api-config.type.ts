export type APIConfig = {
	[key in string]: string;
};
