export { default as LoadingSpinner } from './LoadingSpinner.svelte';
