export { default as SEO } from './SEO.svelte';
