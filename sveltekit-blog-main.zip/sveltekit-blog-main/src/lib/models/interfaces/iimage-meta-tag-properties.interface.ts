export interface IImageMetaTagProperties {
	url: string;
	width: string;
	height: string;
	alt: string;
}
