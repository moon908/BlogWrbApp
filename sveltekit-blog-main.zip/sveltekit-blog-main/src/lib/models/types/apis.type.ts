export type APIS_TYPE = 'IN_MEMORY' | 'CHUCK_NORRIS';
