export interface IApplicationRouteTitle {
	path: string;
	name: string;
}
