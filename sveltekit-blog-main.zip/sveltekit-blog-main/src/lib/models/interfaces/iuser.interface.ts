export interface IUser {
	name: string;
	job: string;
	id: string;
}
