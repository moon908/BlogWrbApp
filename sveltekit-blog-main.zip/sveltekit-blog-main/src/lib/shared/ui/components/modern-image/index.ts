export { default as ModernImage } from './ModernImage.svelte';
