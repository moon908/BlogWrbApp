// LOCAL
export enum SVELTEKIT_DATA_ENPOINTS_DEV {
	SERVICE = '/service',
}

export enum SVELTEKIT_SEARCH_ENPOINTS_DEV {
	SEARCH = '/search',
}
