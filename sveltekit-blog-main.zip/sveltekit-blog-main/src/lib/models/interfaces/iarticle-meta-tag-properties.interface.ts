export interface IArticleMetaTagProperties {
	published_time: string;
	modified_time: string;
	section: string;
	tag: string;
}
