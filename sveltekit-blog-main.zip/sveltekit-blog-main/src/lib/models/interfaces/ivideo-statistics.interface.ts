export interface IVideoStatistics {
	viewCount: number;
}
