export interface ICompiledCSS {
	url: string;
}
